#-*-coding:utf8;-*-
#qpy:2
#qpy:kivy

from kivy.app import App
from kivy.uix.widget import Widget

class Calculator(Widget):
    def add_digit(touch, text_input, digit):
        if text_input is '0':
            return digit
        else:
            text_input = text_input + digit
            return text_input
            
    def calculate(touch,text_input):
        try:
            return str(eval(text_input))
        except:
            return 'Syntax Error'
        
class TestApp(App):
    def build(self):
        return Calculator()

TestApp().run()

